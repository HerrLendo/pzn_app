import 'package:flutter/material.dart';
import 'package:pzn_app/corona_alert-item.dart';
import 'package:pzn_app/item.dart';
import 'package:pzn_app/posts.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 4.0),
          ),
          AlertItem(),

          ///item.dart für Posts wie Bilder etc
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Divider(
              color: Colors.black,
            ),
          ),
          SizedBox(
            height: 355,
            child: PostList(),
          ),
        ],
      ),
    );
  }
}

