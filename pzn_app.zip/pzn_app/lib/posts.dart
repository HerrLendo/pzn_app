import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PostList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new StreamBuilder(
      stream: Firestore.instance.collection('posts').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return Center(child: new Text('Loading...'));
        return new SizedBox(
          height: 18300,
          child: ListView(
            scrollDirection: Axis.vertical,
            children: snapshot.data.documents.map<Widget>((document) {
              return new Center(
                child: Card(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.image,
                          size: 220,
                        ),
                      ),
                      SizedBox(
                        child: ListTile(
                          leading: Icon(Icons.announcement,
                            size: 43,
                            color: Colors.yellow[700],),
                          title: new Text(document['title'], style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                          subtitle: new Text(document['content']),
                        ),
                      ),
                      ButtonBar(
                        children: <Widget>[
                          FlatButton(
                            child: Text('Weiterlesen'),
                            onPressed: (){},
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        );
      },
    );
  }
}

