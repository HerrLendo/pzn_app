package eu.faithlux.pzn_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
